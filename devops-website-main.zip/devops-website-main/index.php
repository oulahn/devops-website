<?php

phpinfo();
//adding something to test
//adding another thing